/*
    1) Callbacks Functions
    2) Promises in JS
    3) Classes in JS
 */