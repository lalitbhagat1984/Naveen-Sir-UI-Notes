// Create a Module
let app = angular.module('AgeSelectionApp',[]);

// Create a Controller
app.controller('AgeSelectionAppCtrl',function($scope) {
    $scope.check = null;
});