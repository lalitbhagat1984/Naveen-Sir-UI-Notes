// Console Logs

// normal Log message
console.log('Welcome to JavaScript');

// info message
console.info('This is an information message');

// Warn message
console.warn('This is a warning Message');

// error message
console.error('This is an error Message');

