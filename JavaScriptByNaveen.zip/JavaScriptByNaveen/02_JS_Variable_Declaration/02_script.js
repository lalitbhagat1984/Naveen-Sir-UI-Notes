let a = 100;
let b = 200;
let sum = a + b;
console.log('The Sum of ' + a + ' , ' + b  + ' is : ' + sum); // Old ES5
console.log(`The Sum of ${a} , ${b} is : ${sum}`); // ES6

// Rules of variable declaration
let empName = 'Jeevan';
console.log(`EMP NAME : ${empName}`);

let empAge = 24;
console.log(`EMP AGE : ${empAge}`);

let empDesignation = 'Software Engineer';
console.log(`EMP DESIGNATION : ${empDesignation}`);


let name = 'John';
name = 'Rajan';
console.log(name);
