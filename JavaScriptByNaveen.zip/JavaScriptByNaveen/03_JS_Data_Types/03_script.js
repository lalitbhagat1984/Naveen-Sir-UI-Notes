// String
let studentName = 'Arjun Reddy';
console.log(`Value : ${studentName} Type : ${typeof studentName}`);

// Number
let studentAge = 23;
console.log(`Value : ${studentAge} Type : ${typeof studentAge}`);

// Boolean
let isMedicalStudent = true;
console.log(`Value : ${isMedicalStudent} Type : ${typeof isMedicalStudent}`);

// undefined
let a;
console.log(`Value : ${a} Type : ${typeof a}`);

// Null
a = null;
console.log(`Value : ${a} Type : ${typeof a}`);

// Re-assignment
let name;
console.log(`Value : ${name} Type : ${typeof name}`);

name = 'test';
console.log(`Value : ${name} Type : ${typeof name}`);

name = 10;
console.log(`Value : ${name} Type : ${typeof name}`);

name = true;
console.log(`Value : ${name} Type : ${typeof name}`);